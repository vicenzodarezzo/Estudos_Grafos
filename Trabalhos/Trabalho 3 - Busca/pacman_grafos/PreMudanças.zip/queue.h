#ifndef QUEUE_H
#define QUEUE_H

#include <stdbool.h>

#define MAX 100

typedef struct queue Queue_t;

Queue_t *queue_create(void);

bool is_empty_queue(Queue_t *Q);
bool is_full_queue(Queue_t *Q);

void enqueue(Queue_t *Q, int e);
int dequeue(Queue_t *Q);

void queue_destroy(Queue_t **Q);

#endif
