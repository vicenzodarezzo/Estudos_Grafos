#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stdbool.h>

#include "graph.h"

int **alocate_square_matrix(int n) {
    int **matrix = (int **) malloc(n * sizeof(int *));
    assert(matrix);
    for(int i = 0; i < n; i++){
        matrix[i] = (int *) malloc(n * sizeof(int));
        assert(matrix[i]);
    }

    return matrix;
}

void fill_matrix(int **matrix, int n) {
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            scanf(" %d", &matrix[i][j]);
        }
    }
}

void delete_matrix(int **matrix, int n){
    for(int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

bool check_conection(int **matrix, int n, int i1, int j1, int i2, int j2){
    if(i2 == -1 || j2 == -1)
        return false;

    if(i2 >= n || j2 >= n)
        return false;
    
    if(matrix[i1][j1] == 1 || matrix[i2][j2] == 1)
        return false;

    return true;
}

int calculate_id(int n, int i, int j){
    return (i * n) + j;
}

void graph_cartesian_association(Graph_t *graph, int **matrix, int n) {
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if(check_conection(matrix, n, i, j, i, j - 1)){
                graph_insert_oriented_edge(graph, calculate_id(n, i, j), calculate_id(n, i, j - 1));
            }

            if(check_conection(matrix, n, i, j, i, j + 1)){
                graph_insert_oriented_edge(graph, calculate_id(n, i, j), calculate_id(n, i, j + 1));
            }

            if(check_conection(matrix, n, i, j, i - 1, j)){
                graph_insert_oriented_edge(graph, calculate_id(n, i, j), calculate_id(n, i - 1, j));
            }
                
            if(check_conection(matrix, n, i, j, i + 1, j)){
                graph_insert_oriented_edge(graph, calculate_id(n, i, j), calculate_id(n, i + 1, j));
            }

        }
    }
}

typedef enum {
    up, down, left, right
} Steps_t;

int main(void) {
    // LEITURA
    int n;
    scanf(" %d", &n);

    int **matrix = alocate_square_matrix(n);
    fill_matrix(matrix, n);

    Graph_t *graph = graph_create(pow(n, 2), 1); //tirar esse 1
    graph_cartesian_association(graph, matrix, n);
    delete_matrix(matrix, n);

    int x, y;
    scanf(" %d %d", &x, &y);
    int pacman_position = calculate_id(n, x, y);
    scanf(" %d %d", &x, &y);
    int phantom_position = calculate_id(n, x, y);

    int max_steps;
    scanf(" %d", &max_steps);

    // VARIAVEIS AUXILIARES
    Steps_t pacman_steps[4];
    pacman_steps[up] = 0;
    pacman_steps[down] = 0;
    pacman_steps[left] = 0;
    pacman_steps[right] = 0;
    
    //verificar se precisa ser "number_nodes + 1" realmente
    int * ancestor = (int *) malloc((get_n_nodes(graph) + 1) * sizeof(int));

    char char_aux;
    
    int n_pacman_steps;
    
    bool stay_stopped = false;
    
    for (n_pacman_steps = 0; n_pacman_steps < max_steps; n_pacman_steps++) {
        
        ancestor = BFS(graph, pacman_position, ancestor);
        
        int prox_passo = phantom_position;
        
        while(ancestor[prox_passo] != pacman_position){
            if(ancestor[prox_passo] != -1 ){
                prox_passo = ancestor[prox_passo];
            }else{
                prox_passo = pacman_position;
                break;
            }
        }
        
        if(prox_passo == pacman_position - 1){
            pacman_steps[left]++;
        } else if(prox_passo == pacman_position + 1){
            pacman_steps[right]++;
        } else if(prox_passo == pacman_position - n){
            pacman_steps[up]++;
        } else if(prox_passo == pacman_position + n){
            pacman_steps[down]++;
        }
        
        pacman_position = prox_passo;
        if(pacman_position == phantom_position) break;
        
        scanf(" %c", &char_aux);
        if(char_aux == 'U') phantom_position = (phantom_position - n) % (int) pow(n, 2);
        if(char_aux == 'D') phantom_position = (phantom_position + n) % (int) pow(n, 2);
        if(char_aux == 'L') phantom_position = (phantom_position - 1) % (int) pow(n, 2);
        if(char_aux == 'R') phantom_position = (phantom_position + 1) % (int) pow(n, 2);
    }
    
    if(get_initial_edge(graph, phantom_position) != NULL){
        
        while(pacman_position != phantom_position && !stay_stopped){
            
            ancestor = BFS(graph, pacman_position, ancestor);
            
            int prox_passo = phantom_position;
        
            while(ancestor[prox_passo] != pacman_position){
                if(ancestor[prox_passo] != -1 ){
                    prox_passo = ancestor[prox_passo];
                }else{
                    prox_passo = pacman_position;
                    stay_stopped = true;
                    break;
                }
            }
            
            if(prox_passo == pacman_position - 1){
                pacman_steps[left]++;
            } else if(prox_passo == pacman_position + 1){
                pacman_steps[right]++;
            } else if(prox_passo == pacman_position - n){
                pacman_steps[up]++;
            } else {
                pacman_steps[down]++;
            }
            pacman_position = prox_passo;

            n_pacman_steps++;
        }
    }

    if (pacman_position == phantom_position){
        int total_steps = pacman_steps[up] + pacman_steps[down] + pacman_steps[left] + pacman_steps[right];
        
        
        printf("Número de passos: %d\n", total_steps);
        printf("Movimentos para cima: %d\n", pacman_steps[up]);
        printf("Movimentos para baixo: %d\n", pacman_steps[down]);
        printf("Movimentos para esquerda: %d\n", pacman_steps[left]);
        printf("Movimentos para direita: %d\n", pacman_steps[right]);
    } else {
        printf("Não foi possível achar um caminho\n");
    }

    free(ancestor);
    graph_delete(&graph);
}
